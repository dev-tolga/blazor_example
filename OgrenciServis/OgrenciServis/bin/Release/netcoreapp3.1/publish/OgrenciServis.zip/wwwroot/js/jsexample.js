﻿window.JsInteropFunction = function (input) {
    $('#testSercan').modal('show');
}

window.AlertCustom = function () {
    $('#modalKayitAlert').modal('show');
}

window.SaveSuccess = function () {
    $('#modalKayitBasarili').modal('show');
}